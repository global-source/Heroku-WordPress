<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );

$query_args = array(
    'post_type'           => 'product',
    'post_status'         => 'publish',
    'ignore_sticky_posts' => 1,
    'posts_per_page'      => $atts['per_page'],
    'meta_key'            => 'total_sales',
    'orderby'             => 'meta_value_num',
    'paged'               => $atts['paged'],
    'meta_query'          => WC()->query->get_meta_query()
);

LaStudio_Shortcodes_Helper::getLoopProducts($query_args, $atts, $this->getShortcode());