<?php
/*
 * Template loop-end
 */
global $cosy_loop;
$cosy_loop = array();
?>
    </div>
<!-- ./end-main-loop -->