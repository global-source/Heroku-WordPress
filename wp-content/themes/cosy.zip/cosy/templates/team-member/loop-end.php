<?php
/*
 * Template loop-end
 */
global $cosy_member_loop_index, $cosy_loop;
$cosy_member_loop_index = '';
$loop_style = isset($cosy_loop['loop_style']) ? $cosy_loop['loop_style'] : 1;
?>
</div>
<!-- .team-member-loop -->
